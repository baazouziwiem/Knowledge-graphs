The query can be run using any SPARQL processor. You can also run the query online using RDFShape following [this link](https://tinyurl.com/y384u3bt).
