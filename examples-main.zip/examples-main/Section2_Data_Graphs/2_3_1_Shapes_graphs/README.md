The example can be run using [shex-s](http://www.weso.es/shex-s/) with the following invocation:

```
shex-s --dataFile figure1.ttl --schemaFile figure7.shex --shapeMap :EID15@:Event,:EID16@:Event
```

It can also be run using the online [rdfshape demo](http://rdfshape.weso.es) with the [following permalink](https://tinyurl.com/yyfq2p4f).
